﻿Public Class DocTypeDialog
    Private Sub DocTypeDialog_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

End Class