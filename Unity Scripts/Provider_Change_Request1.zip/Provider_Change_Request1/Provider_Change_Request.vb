Imports Kofax.AscentCapture.NetScripting
Imports Kofax.Capture.CaptureModule.InteropServices
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data.Odbc

' 2025      Original Development        Fred Bullmer
'***************************************************************
'11/20/2025 FCB         Improvements per UAT
'
'
'


Namespace Provider_Change_Request
	
	<SuppressFieldEventsOnDocClose(false)>  _
	Public Class Provider_Change_Request
		Inherits DocumentValidationScript

#Region "Document Fields"
		<IndexFieldVariableAttribute("Tax ID#")> Dim WithEvents Tax_ID_ As FieldScript
		<IndexFieldVariableAttribute("Provider Name")> Dim WithEvents Provider_Name As FieldScript
		<IndexFieldVariableAttribute("Document Date")> Dim WithEvents Document_Date As FieldScript
		<IndexFieldVariableAttribute("DTN")> Dim WithEvents DTN As FieldScript
		<IndexFieldVariableAttribute("Name Verify")> Dim WithEvents Name_Verify As FieldScript

		Dim dbConStr As String = String.Empty       'Obtain from hidden Batch field
		Dim bypassDatabase As Boolean = False       'set if not found
		Dim dbDT As DataTable = New DataTable       'set as result of query
		Dim sqlQ As String = String.Empty           'current sql query
		Dim valFlag As Boolean = False
#End Region

#Region "Batch Handling"
		Sub New(ByVal bIsValidation As Boolean, ByVal strUserID As String, ByVal strLocaleName As String)
			MyBase.New(bIsValidation, strUserID, strLocaleName)
		End Sub

		Private Sub Provider_Change_Request_BatchLoading(sender As Object, e As BatchEventArgs) Handles Me.BatchLoading
			'"DSN=SWIFPCP1;UID=KOFAX_USR;PWD=KOFAX_USR
			Try         'aquire external db connection string
				dbConStr = e.Batch.BatchFields.Item("DBConStr").Value
				If dbConStr.Length < 1 Then bypassDatabase = True
			Catch ex As Exception
				Throw New FatalErrorException("Please add 'DBConStr' as a hidden Batch Field")
			End Try

		End Sub


		Private Sub Provider_Change_Request_DocumentPreProcessing(sender As Object, e As PreDocumentEventArgs) Handles Me.DocumentPreProcessing
			'use to skip on initial indexing but not if already processed
			valFlag = e.AlreadyProcessed
		End Sub


#End Region


#Region "Field Handling"
		Private Sub Tax_ID__FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Tax_ID_.FieldPostProcessing
			If String.IsNullOrWhiteSpace(Tax_ID_.IndexField.Value) Then
				Throw New ValidationErrorException("Tax ID Number is empty")
			End If
			If Not IsNumeric(Tax_ID_.IndexField.Value) Then
				MsgBox("Tax Id must be numeric", vbOKOnly, "Validation Error")
				Throw New ValidationErrorException("Tax ID Number is empty")
			End If
			Try
				Tax_ID_.IndexField.Value = Int32.Parse(Tax_ID_.IndexField.Value.Trim).ToString("000000000")
			Catch ex As Exception
				Throw New ValidationErrorException("Tax ID Number is invalid")
			End Try
			'THIS NEEDS TO BE REPLACED WITH A VIEW OR EXTERNAL HIDDEN BATCH FIELD
			sqlQ = New String($"select LGL_ENTY_DRV_NM from Legal_entity where LGL_ENTY_DRV_TAX_ID = '{Tax_ID_.IndexField.Value}'")
			Try
				dbDT = FillDT(sqlQ, dbConStr)
			Catch ex As Exception
				MsgBox("SQL Error searching for Tax ID: " & vbCrLf & ex.Message, , "Validation Error")
				Throw New ValidationErrorException(ex.Message)
			End Try

			If dbDT.Rows.Count < 1 Then
				MsgBox("The Tax ID entered is not on file.", , "Validation Error")
				Throw New ValidationErrorException("The Tax ID entered is not on file.")
			End If

			If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(0)) Then
				Provider_Name.IndexField.Value = dbDT.Rows(0).Item(0).ToString().Trim()
			Else
				MsgBox("Provider Name is blank.", vbOKOnly, "Validation Error")
			End If
		End Sub

		Private Sub Document_Date_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Document_Date.FieldPostProcessing
			Document_Date.IndexField.Value = Format_Date(Document_Date.IndexField.Value)
			If Not IsDate(Document_Date.IndexField.Value) Then
				MsgBox("Invalid Date",, "Validation Error")
				Throw New ValidationErrorException("Invalid Date")
			End If
			'Removed Future Test  11/20/2025
			'If Date.Parse(Document_Date.IndexField.Value) > Now Then
			'    MsgBox("Invalid Date",, "Validation Error")
			'    Throw New ValidationErrorException("Invalid Date")
			'End If
		End Sub

#End Region

#Region "Toolbox"
		Function Format_Date(ByVal TestValue As String) As String
			If String.IsNullOrWhiteSpace(TestValue) Then
				Return String.Empty
			End If
			If IsNumeric(TestValue) Then
				Select Case TestValue.Length
					Case 6
						Return DateTime.ParseExact(TestValue, "MMddyy", Nothing).ToString("MM/dd/yyyy")
					Case 8
						Return DateTime.ParseExact(TestValue, "MMddyyyy", Nothing).ToString("MM/dd/yyyy")
					Case Else
						Return String.Empty
				End Select
			End If
			If IsDate(TestValue) Then
				Return Date.Parse(TestValue).ToString("MM/dd/yyyy")
			End If
			Return String.Empty
		End Function

		Function FillDT(ByVal dbSql As String, ByVal dbConStr As String) As DataTable
			Dim dbDT As New DataTable()
			If bypassDatabase Then Return dbDT
			Using dbConn As New OdbcConnection(dbConStr)
				dbConn.Open()
				Using dbAdapt As New OdbcDataAdapter(dbSql, dbConn)
					dbAdapt.Fill(dbDT)
				End Using
				dbConn.Close()
			End Using
			Return dbDT
		End Function
#End Region

	End Class
End Namespace
