REM ========================================================================
REM
REM   Document Class Script Name: Provider Change Request
REM
REM
REM ------------------------------------------------------------------------


Option Explicit


REM ========================================================================
REM Numeric validation DLL declarations.
REM ------------------------------------------------------------------------

Declare Function KfxValidateDecimal Lib "KfxValid.dll" _
        (DecimalString As String, ByVal Precision As Integer, _
        ByVal Scale As Integer) As Integer
Declare Function KfxFormatDecimal Lib "KfxValid.dll" _
        (DecimalString As String, ByVal Precision As Integer, _
        ByVal Scale As Integer) As Integer
Declare Function KfxRoundInteger Lib "KfxValid.dll"      (InValue as String, ByRef OutValue as long) as Integer 
Declare Function KfxRoundSmallInteger Lib "KfxValid.dll" (InValue as String, ByRef OutValue as integer) as Integer 
Declare Function KfxValidateDouble Lib "KfxValid.dll" (DoubleString As String) As Integer
Declare Function KfxFormatDouble Lib "KfxValid.dll" (DoubleString As String) As Integer
Declare Function KfxValidateReal Lib "KfxValid.dll" (RealString As String) As Integer
Declare Function KfxFormatReal Lib "KfxValid.dll" (RealString As String) As Integer

REM ========================================================================
REM Return codes shared with Indexing Application, do not modify.
REM ------------------------------------------------------------------------

   ' Rejects the current document and moves to the next unprocessed one

const RejectAndSkipDocument= -4

   ' Indicates validation error.  Indexing application displays error msg
   ' and it does not advance to the next field on the indexing form.

const ValidationError      = -3

   ' Indicates validation error.  Indexing application does not display
   ' any error message and it does not advance to the next field on the
   ' indexing form.

const ValidationErrorNoMsg = -2

   ' Indicates fatal error.  Batch is set to error state.

const FatalError           = -1

   ' Indicates successful operation.  If this is returned from an post
   ' index field function, the indexing application advances to the next
   ' field on the form.

const NoError              = 0

   ' Indicates that the values in the document should all be saved
   ' and the indexing applications should advance to the next
   ' document.  WARNING:  This feature should be used with caution
   ' as no validation will be performed on any of the subsequent
   ' index fields for the current document, including ensuring
   ' that an index field marked as 'required' may be left blank.
   ' NOTE: The DocPostProcess function is still called after a
   ' SaveAndSkip 

const SaveAndSkipDocument  = 1

   ' When returned from the pre-field trigger, this code
   ' causes the same behavior as if the tab (or enter) key was pressed
   ' in the current field.

const SaveAndSkipField     = 2

   ' Indicates that the corresponding default script behavior will be executed after
   ' the current custom script function.

const NoOperation          = 3



REM ========================================================================
REM Misc variables for script customization.
REM ------------------------------------------------------------------------

   ' The default behavior is for the indexing application to call the
   ' pre-focus-document and post-focus-document functions only for those
   ' documents that the user interacts with.  So, when a suspended batch
   ' (partially indexed) is again processed, pre and post focus are called
   ' only for the documents that the user processes.  The already indexed
   ' documents are skipped.
   ' For the case where the script is accumulating, it may be desirable
   ' to call the document pre and post focus functions for all documents
   ' including those that have been previously indexed.  If this is the
   ' case, the variable KfxLoadAllProcessedValues must be set to YES else
   ' don't define it or set it to NO.

Global const KfxLoadAllProcessedValues = "NO"

   ' Must be present!   Indicates type of operation being done, index or
   ' index verify.

Global KfxOperation As String
         
   ' If present, this read-only variable is set to the name of the batch
   ' being processed.

Dim KfxBatchName As String

   ' If present, this read-only variable is set to the id of the batch
   ' being processed.

Dim KfxBatchId As String

   ' Uncomment the definition below if the Batch Class Id associated
   ' with the batch being processed is required.

'Dim KfxBatchClassId As String

   ' If present, this read-only variable is set to the name of the
   ' document class associated with the batch being processed.

Dim KfxClassName As String

   ' Uncomment the definition below if the Document Class Id associated
   ' with the batch being processed is required.

'Dim KfxDocClassId As String
   
   ' Uncomment the definition below if the script is to have 
   ' access to the page image associated with the current index field.  

' Dim KfxPageFile As String

   ' Uncomment the definition below if the script wants to change
   ' the error messages (and thus the document notes and batch history
   ' entries) produced when returning FatalError or RejectAndSkip
   ' from any function (except the format calls)

' Dim KfxErrorMessage As String

Dim Result as Integer
Global KfxProvider_Name As String   
Global ConnectionPC as Long
Global errors(1 to 3, 1 to 10) as Variant

REM ========================================================================
REM Index fields processed by pre, post, or format procedures must be
REM defined above before any of the functions that actually use them.
REM ------------------------------------------------------------------------


REM ========================================================================
REM Function handling initialization for this module.
REM This function is called after the user opens a batch.  The function is
REM called once per batch and is called and before any other function in
REM this module.
REM ------------------------------------------------------------------------

Function KfxLoadValidation ( VerifyBatch As Integer, _
              NumberOfDocsInBatch As Integer ) As Integer
   On Error GoTo Failure

   If (VerifyBatch <> 0) Then
      KfxOperation = "Verify"
   Else
      KfxOperation = "Index"
   End If
   
Rem // Open the PowerComp database with the ODBC string.
         
        ConnectionPC=SQLOpen("DSN=SWIFPCP1;UID=KOFAX_USR;PWD=KOFAX_USR")
        
        If ConnectionPC < 0 then
            SQLError destination:=errors
            msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "ODBC Connection Failed"
            goto failure
        End if    
   
Rem // End   
   
   KfxLoadValidation = NoError
   Exit Function

Failure:
   KfxLoadValidation = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling termination of this module.
REM This function is called upon end of processing for the batch.  The
REM function is called once per batch and is the last function to be
REM called from this module.
REM ------------------------------------------------------------------------

Function KfxUnloadValidation ( ) As Integer
   On Error GoTo Failure

   Result=SQLClose(ConnectionPC)

   KfxUnloadValidation = NoError
   Exit Function

Failure:
   KfxUnloadValidation = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling document pre index processing.
REM This function can return NoError, FatalError, or SaveAndSkipDocument. 
REM
REM NOTE:
REM   We recommend not returning SaveAndSkipDocument if the document
REM   has already been processed.  In the case where all the documents
REM   in the batch have been processed (indexed), returning
REM   SaveAndSkipDocument will prevent the indexing application from
REM   stopping on any document in the batch.
REM ------------------------------------------------------------------------

Function KfxDocPreProcess ( Id As Long, NumberOfPages As Integer, _
             AlreadyProcessed As Integer) As Integer
   On Error GoTo Failure

   If (AlreadyProcessed) Then
      KfxDocPreProcess = NoError
      Exit Function
   End If

   KfxDocPreProcess = NoError
   Exit Function

Failure:
   KfxDocPreProcess = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling document post index processing.
REM This function can return NoError or FatalError.
REM ------------------------------------------------------------------------

Function KfxDocPostProcess ( Id As Long, DataAccepted As Integer) As Integer
   On Error GoTo Failure

   Dim Operation As String                ' example code
   If (DataAccepted = 1) Then             ' example code
      Operation = "Requested Save Index Data" ' example code
   Else                             ' example code
      Operation = "Cancelled Save Index Data" ' example code
   End If                              ' example code

   KfxDocPostProcess = NoError
   Exit Function

Failure:
   KfxDocPostProcess = FatalError
   Exit Function
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLTax_ID_ As String

                     ' Index field value.

Global KfxTax_ID_ As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Tax_ID_ default value: ""
                     '-----------------------------------------------
Function PreTax_ID_() As Integer
   On Error GoTo Failure
   PreTax_ID_ = NoError
   Exit Function
Failure:
   PreTax_ID_ = FatalError
   Exit Function
End Function
                     '----- Tax_ID_ validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostTax_ID_( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   

Dim SQL as Variant
Dim Result as integer
Dim EntityArray(1,1) as Variant

   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
rem   If isnumeric(EnteredValue) then
rem      continue 
rem   else
   If not isnumeric(EnteredValue) then
      SQLError destination:=errors
      msgbox "Tax Id must be numeric"  
      goto failure
   End if 
   
      SQL = "select LGL_ENTY_DRV_NM from Legal_entity where LGL_ENTY_DRV_TAX_ID = "
      SQL = SQL & "'" & EnteredValue & "'"
      
 
   Result = SQLExecQuery(ConnectionPC, SQL)
  
   If Result <= 0 then
     SQLError destination:=errors
     msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
     goto failure
   End if

   Result = SQLRetrieve(ConnectionPC, EntityArray)   
     
   If Result = 0 then
      SQLError destination:=errors
      msgbox "Invalid Tax Id "  
      goto failure
   End if  
   
   KfxTax_ID_ = EnteredValue
   
KfxProvider_Name = EntityArray(0,0)   
   
   PostTax_ID_ = NoError
   Exit Function
Failure:
   PostTax_ID_ = ValidationError
   Exit Function
End Function
                     '----- Tax_ID_ format
                     '-----------------------------------------------
Function FmtTax_ID_() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtTax_ID_ = KfxTax_ID_
   Exit Function
Failure:
   FmtTax_ID_ = KfxTax_ID_
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLProvider_Name As String

                     ' Index field value.

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Provider_Name default value: ""
                     '-----------------------------------------------
Function PreProvider_Name() As Integer
   On Error GoTo Failure
   PreProvider_Name = SAVEANDSKIPFIELD
   Exit Function
Failure:
   PreProvider_Name = FatalError
   Exit Function
End Function
                     '----- Provider_Name validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostProvider_Name( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxProvider_Name = EnteredValue
   PostProvider_Name = noerror
   Exit Function
Failure:
   PostProvider_Name = ValidationError
   Exit Function
End Function
                     '----- Provider_Name format
                     '-----------------------------------------------
Function FmtProvider_Name() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtProvider_Name = KfxProvider_Name
   Exit Function
Failure:
   FmtProvider_Name = KfxProvider_Name
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDocument_Date As String

                     ' Index field value.

Global KfxDocument_Date As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Document_Date default value: ""
                     '-----------------------------------------------
Function PreDocument_Date() As Integer
   On Error GoTo Failure
   PreDocument_Date = NoError
   Exit Function
Failure:
   PreDocument_Date = FatalError
   Exit Function
End Function
                     '----- Document_Date validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDocument_Date( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxDocument_Date = EnteredValue
   PostDocument_Date = NoError
   Exit Function
Failure:
   PostDocument_Date = ValidationError
   Exit Function
End Function
                     '----- Document_Date format
                     '-----------------------------------------------
Function FmtDocument_Date() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDocument_Date = KfxDocument_Date
   Exit Function
Failure:
   FmtDocument_Date = KfxDocument_Date
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDTN As String

                     ' Index field value.

Global KfxDTN As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- DTN default value: ""
                     '-----------------------------------------------
Function PreDTN() As Integer
   On Error GoTo Failure
   PreDTN = NoError
   Exit Function
Failure:
   PreDTN = FatalError
   Exit Function
End Function
                     '----- DTN validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDTN( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxDTN = EnteredValue
   PostDTN = NoError
   Exit Function
Failure:
   PostDTN = ValidationError
   Exit Function
End Function
                     '----- DTN format
                     '-----------------------------------------------
Function FmtDTN() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDTN = KfxDTN
   Exit Function
Failure:
   FmtDTN = KfxDTN
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLName_Verify As String

                     ' Index field value.

Global KfxName_Verify As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Name_Verify default value: ""
                     '-----------------------------------------------
Function PreName_Verify() As Integer
   On Error GoTo Failure
   PreName_Verify = NoError
   Exit Function
Failure:
   PreName_Verify = FatalError
   Exit Function
End Function
                     '----- Name_Verify validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostName_Verify( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxName_Verify = EnteredValue
   PostName_Verify = NoError
   Exit Function
Failure:
   PostName_Verify = ValidationError
   Exit Function
End Function
                     '----- Name_Verify format
                     '-----------------------------------------------
Function FmtName_Verify() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtName_Verify = KfxName_Verify
   Exit Function
Failure:
   FmtName_Verify = KfxName_Verify
End Function


Sub Main
dim Result as Integer
Result = KfxLoadValidation(1,0)
rem Result = PostTax_ID_( "198585261",9)
Result = PostTax_ID_( "455555555",9)
Result = KfxUnLoadValidation()
End Sub 
