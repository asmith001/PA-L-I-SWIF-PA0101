Imports Kofax.AscentCapture.NetScripting
Imports Kofax.Capture.CaptureModule.InteropServices
Imports System
Imports System.Collections.Generic
Imports System.Data.Odbc
Imports System.Text


Namespace QA106___PPAF

    <SuppressFieldEventsOnDocClose(False)>
    Public Class QA106___PPAF
        Inherits DocumentValidationScript
        <IndexFieldVariableAttribute("Policy Number")> Dim WithEvents Policy_Number As FieldScript
        <IndexFieldVariableAttribute("Insured Name")> Dim WithEvents Insured_Name As FieldScript
        <IndexFieldVariableAttribute("Tax ID")> Dim WithEvents Tax_ID As FieldScript
        <IndexFieldVariableAttribute("Document Date")> Dim WithEvents Document_Date As FieldScript
        <IndexFieldVariableAttribute("Audit Number")> Dim WithEvents Audit_Number As FieldScript
        <IndexFieldVariableAttribute("Name_verify")> Dim WithEvents Name_verify As FieldScript

        Dim dbConStr As String = String.Empty       'Obtain from hidden Batch field
        Dim bypassDatabase As Boolean = False       'set if not found
        Dim dbDT As DataTable = New DataTable       'set as result of query
        Dim sqlQ As String = String.Empty           'current sql query

        Dim valFlag As Boolean = False

#Region "Batch Handling"
        Sub New(ByVal bIsValidation As Boolean, ByVal strUserID As String, ByVal strLocaleName As String)
            MyBase.New(bIsValidation, strUserID, strLocaleName)
        End Sub

        Private Sub Policy_Document_BatchLoading(sender As Object, e As BatchEventArgs) Handles Me.BatchLoading
            Try         'aquire external db connection string
                dbConStr = e.Batch.BatchFields.Item("DBConStr").Value
                If dbConStr.Length < 1 Then bypassDatabase = True
            Catch ex As Exception
                Throw New FatalErrorException("Please add 'DBConStr' as a hidden Batch Field")
            End Try
        End Sub

        Private Sub Policy_Document_DocumentPreProcessing(sender As Object, e As PreDocumentEventArgs) Handles Me.DocumentPreProcessing
            'use to skip on initial indexing but not if already processed
            valFlag = e.AlreadyProcessed
        End Sub


#End Region

#Region "Field Handling"
        Private Sub Policy_Number_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Policy_Number.FieldPostProcessing
            If String.IsNullOrWhiteSpace(Policy_Number.IndexField.Value) Then
                Throw New ValidationErrorException("Policy Number is empty")
            End If
            Try
                Policy_Number.IndexField.Value = Int32.Parse(Policy_Number.IndexField.Value.Trim).ToString("00000000")
            Catch ex As Exception
                Throw New ValidationErrorException("Policy Number is invalid")
            End Try

            'THIS NEEDS TO BE REPLACED WITH A VIEW OR EXTERNAL HIDDEN BATCH FIELD
            sqlQ = New String($"SELECT KS267, KS268 FROM HSI.KEYSETDATA132 WHERE KS181 = '{Policy_Number.IndexField.Value}'")
            Try
                dbDT = FillDT(sqlQ, dbConStr)
            Catch ex As Exception
                MsgBox("SQL Error searching for Policy: " & vbCrLf & ex.Message, , "Validation Error")
                Throw New ValidationErrorException(ex.Message)
            End Try

            If dbDT.Rows.Count < 1 Then
                MsgBox("The Policy Number entered is not on file.", , "Validation Error")
                Throw New ValidationErrorException("The Policy Number entered is not on file.")
            End If

            If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(0)) Then
                Insured_Name.IndexField.Value = dbDT.Rows(0).Item(0).ToString().Trim()
            Else
                MsgBox("Insured Name is blank.  Please Reject this document.",, "Validation Error")
            End If
            If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(1)) Then
                Tax_ID.IndexField.Value = dbDT.Rows(0).Item(1).ToString().Trim()
            End If

        End Sub

        Private Sub Insured_Name_FieldPreProcessing(sender As Object, e As PreFieldEventArgs) Handles Insured_Name.FieldPreProcessing
            If Not valFlag Then e.SkipMode = PreFieldEventArgs.SkipModeEnum.SaveAndSkipField
        End Sub

        Private Sub Tax_ID_FieldPreProcessing(sender As Object, e As PreFieldEventArgs) Handles Tax_ID.FieldPreProcessing
            If Not valFlag Then e.SkipMode = PreFieldEventArgs.SkipModeEnum.SaveAndSkipField
        End Sub

        Private Sub Document_Date_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Document_Date.FieldPostProcessing
            Document_Date.IndexField.Value = Format_Date(Document_Date.IndexField.Value)
            If Not IsDate(Document_Date.IndexField.Value) Then
                MsgBox("Invalid Date",, "Validation Error")
                Throw New ValidationErrorException("Invalid Date")
            End If
            If Date.Parse(Document_Date.IndexField.Value) > Now Then
                MsgBox("Invalid Date",, "Validation Error")
                Throw New ValidationErrorException("Invalid Date")
            End If
        End Sub

        Private Sub Audit_Number_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Audit_Number.FieldPostProcessing
            Audit_Number.IndexField.Value = Audit_Number.IndexField.Value.Trim
            If String.IsNullOrWhiteSpace(Audit_Number.IndexField.Value) Or
                    Audit_Number.IndexField.Value = "-" Then
                Audit_Number.IndexField.Value = "   "
                Exit Sub
            End If
            If Audit_Number.IndexField.Value.Length > 6 Then
                Exit Sub
            End If

            sqlQ = New String($"select pa.plcy_audt_no from policy_audit pa, Policy where Policy.plcy_no = '{Policy_Number.IndexField.Value}' " &
                                $"' and policy.plcy_id = pa.plcy_id and pa.plcy_audt_no = '{Audit_Number.IndexField.Value}'")

            Try
                dbDT = FillDT(sqlQ, dbConStr)
            Catch ex As Exception
                MsgBox("SQL Error searching for Audit #: " & vbCrLf & ex.Message, , "Validation Error")
                Throw New ValidationErrorException(ex.Message)
            End Try

            If dbDT.Rows.Count < 1 Then
                MsgBox("Invalid Audit Number", , "Validation Error")
                Throw New ValidationErrorException("Invalid Audit Number")
            End If

        End Sub



#End Region

#Region "Toolbox"
        Function Format_Date(ByVal TestValue As String) As String
            If String.IsNullOrWhiteSpace(TestValue) Then
                Return String.Empty
            End If
            If IsNumeric(TestValue) Then
                Select Case TestValue.Length
                    Case 6
                        Return DateTime.ParseExact(TestValue, "MMddyy", Nothing).ToString("MM/dd/yyyy")
                    Case 8
                        Return DateTime.ParseExact(TestValue, "MMddyyyy", Nothing).ToString("MM/dd/yyyy")
                    Case Else
                        Return String.Empty
                End Select
            End If
            If IsDate(TestValue) Then
                Return Date.Parse(TestValue).ToString("MM/dd/yyyy")
            End If
            Return String.Empty
        End Function

        Function FillDT(ByVal dbSql As String, ByVal dbConStr As String) As DataTable
            Dim dbDT As New DataTable()
            If bypassDatabase Then Return dbDT
            Using dbConn As New OdbcConnection(dbConStr)
                dbConn.Open()
                Using dbAdapt As New OdbcDataAdapter(dbSql, dbConn)
                    dbAdapt.Fill(dbDT)
                End Using
                dbConn.Close()
            End Using
            Return dbDT
        End Function
#End Region

    End Class
End Namespace
