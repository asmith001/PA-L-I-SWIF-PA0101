Imports Kofax.AscentCapture.NetScripting
Imports Kofax.Capture.CaptureModule.InteropServices
Imports System
Imports System.Collections.Generic
Imports System.Data.Odbc
Imports System.Text
Imports Kofax.AscentCapture.NetScripting.PreFieldEventArgs

' 2025      Original Development        Fred Bullmer
'***************************************************************
'11/20/2025 FCB         Improvements per UAT
'
'
'

Namespace Correspondence_Sent

    <SuppressFieldEventsOnDocClose(False)>
    Public Class Correspondence_Sent
        Inherits DocumentValidationScript
        <IndexFieldVariableAttribute("Claim Number")> Dim WithEvents Claim_Number As FieldScript
        <IndexFieldVariableAttribute("Claimant Name")> Dim WithEvents Claimant_Name As FieldScript
        <IndexFieldVariableAttribute("SSN")> Dim WithEvents SSN As FieldScript
        <IndexFieldVariableAttribute("Document Type")> Dim WithEvents Document_Type As FieldScript
        <IndexFieldVariableAttribute("Document Date")> Dim WithEvents Document_Date As FieldScript
        <IndexFieldVariableAttribute("Medical Flag")> Dim WithEvents Medical_Flag As FieldScript
        <IndexFieldVariableAttribute("Policy Number")> Dim WithEvents Policy_Number As FieldScript
        <IndexFieldVariableAttribute("DTN")> Dim WithEvents DTN As FieldScript


        Dim dbConStr As String = String.Empty       'Obtain from hidden Batch field
        Dim bypassDatabase As Boolean = False       'set if not found
        Dim dbDT As DataTable = New DataTable       'set as result of query
        Dim sqlQ As String = String.Empty           'current sql query

        Dim valFlag As Boolean = False

#Region "Batch Handling"
        Sub New(ByVal bIsValidation As Boolean, ByVal strUserID As String, ByVal strLocaleName As String)
            MyBase.New(bIsValidation, strUserID, strLocaleName)
        End Sub

        Private Sub Correspondence_Sent_BatchLoading(sender As Object, e As BatchEventArgs) Handles Me.BatchLoading
            Try         'aquire external db connection string
                dbConStr = e.Batch.BatchFields.Item("DBConStr").Value
                If dbConStr.Length < 1 Then bypassDatabase = True
            Catch ex As Exception
                Throw New FatalErrorException("Please add 'DBConStr' as a hidden Batch Field")
            End Try

        End Sub

        Private Sub Correspondence_Send_DocumentPreProcessing(sender As Object, e As PreDocumentEventArgs) Handles Me.DocumentPreProcessing
            'use to skip on initial indexing but not if already processed
            valFlag = e.AlreadyProcessed
        End Sub
#End Region

#Region "Field Handling"
        Private Sub Claim_Number_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Claim_Number.FieldPostProcessing
            If String.IsNullOrWhiteSpace(Claim_Number.IndexField.Value) Then
                Throw New ValidationErrorException("Claim Number is empty")
            End If
            'Added length test 11/20/2025
            If Claim_Number.IndexField.Value.Length < 8 Then
                Try
                    Claim_Number.IndexField.Value = Int32.Parse(Claim_Number.IndexField.Value.Trim).ToString("00000000")
                Catch ex As Exception
                    Throw New ValidationErrorException("Claim Number is invalid")
                End Try
            End If
            'THIS NEEDS TO BE REPLACED WITH A VIEW OR EXTERNAL HIDDEN BATCH FIELD
            sqlQ = New String($"SELECT KS259, KS118, KS181 FROM HSI.KEYSETDATA146 WHERE KS102 = '{Claim_Number.IndexField.Value}'")

            Try
                dbDT = FillDT(sqlQ, dbConStr)
            Catch ex As Exception
                MsgBox("SQL Error searching for claim: " & vbCrLf & ex.Message, , "Validation Error")
                Throw New ValidationErrorException(ex.Message)
            End Try

            If dbDT.Rows.Count < 1 Then
                MsgBox("The Claim Number entered is not on file.", , "Validation Error")
                Throw New ValidationErrorException("The Claim Number entered is not on file.")
            End If

            If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(0)) Then
                Claimant_Name.IndexField.Value = dbDT.Rows(0).Item(0).ToString().Trim()
            Else
                MsgBox("Claimant Name is blank.  Please Reject this document.",, "Validation Error")
            End If
            If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(1)) Then
                SSN.IndexField.Value = dbDT.Rows(0).Item(1).ToString().Trim()
            End If
            If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(2)) Then
                Policy_Number.IndexField.Value = dbDT.Rows(0).Item(2).ToString().Trim()
            End If
        End Sub

        Private Sub Claimant_Name_FieldPreProcessing(sender As Object, e As PreFieldEventArgs) Handles Claimant_Name.FieldPreProcessing
            If Not valFlag Then e.SkipMode = SkipModeEnum.SaveAndSkipField
        End Sub

        Private Sub SSN_FieldPreProcessing(sender As Object, e As PreFieldEventArgs) Handles SSN.FieldPreProcessing
            If Not valFlag Then e.SkipMode = SkipModeEnum.SaveAndSkipField
        End Sub

        Private Sub Document_Type_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Document_Type.FieldPostProcessing
            If String.IsNullOrWhiteSpace(Document_Type.IndexField.Value) Then
                MsgBox("Please enter a Document Type.",, "Validation Error")
                Throw New ValidationErrorException("Missing Document Type")
            End If
            Document_Type.IndexField.Value = Document_Type.IndexField.Value.Trim

            'THIS SHOULD BE A EXTERNALLY MAINTAINED DICTIONARY
            Select Case Document_Type.IndexField.Value
                Case "mm"
                    Document_Type.IndexField.Value = "Medical Management Documents"
                    Exit Sub
                Case "voc"
                    Document_Type.IndexField.Value = "Vocational Rehabilitation Documents"
                    Exit Sub
                Case "sur", "srv"
                    Document_Type.IndexField.Value = "Surveillance/Investigation Documents"
                    Exit Sub
                Case "ire"
                    Document_Type.IndexField.Value = "IRE/Impairment Rating Evaluation"
                    Exit Sub
                Case "lcr"
                    Document_Type.IndexField.Value = "Legal Correspondence Received"
                    Exit Sub
                Case "lcs"
                    Document_Type.IndexField.Value = "Legal Correspondence Sent"
                    Exit Sub
                Case "md"
                    Document_Type.IndexField.Value = "Medical Documents"
                    Exit Sub
                Case "mn"
                    Document_Type.IndexField.Value = "Mediation Notice"
                    Exit Sub
                Case "i"
                    Document_Type.IndexField.Value = "Indemity Documents"
                    Exit Sub
                Case "mb"
                    Document_Type.IndexField.Value = "Miscellaneous Bills"
                    Exit Sub
                Case "cs"
                    Document_Type.IndexField.Value = "Correspondence Sent"
                    Exit Sub
                Case "cr"
                    Document_Type.IndexField.Value = "Correspondence Received"
                    Exit Sub
                Case "201"
                    Document_Type.IndexField.Value = "D201 - Domestic Relations"
                    Exit Sub
                Case "co"      'mis-cased in SBL too
                    Document_Type.IndexField.Value = "court Document"
                    Exit Sub
                Case "105"
                    Document_Type.IndexField.Value = "L105 - Petitions"
                    Exit Sub
                Case "109"
                    Document_Type.IndexField.Value = "L109 - Subpoenas"
                    Exit Sub
                Case "107"
                    Document_Type.IndexField.Value = "L107 - Third Party Subrogation"
                    Exit Sub
                Case "ice"
                    Document_Type.IndexField.Value = "ICE REPORT ( LIBC 116 )"
                    Exit Sub
                Case "la"
                    Document_Type.IndexField.Value = "Legal Analysis Report"
                    Exit Sub
                Case "v"
                    Document_Type.IndexField.Value = "Vendor Action Form"
                    Exit Sub
            End Select

            REM // First check for an exact match for the Entered Value.  If exact match, fill the 
            REM // index field and move on.

            'Another hard coded sql string with hsi specific code that be reviewed
            sqlQ = New String($"SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) = Upper('{Document_Type.IndexField.Value}') and ITEMTYPEGROUPNUM = '105'")

            Try
                dbDT = FillDT(sqlQ, dbConStr)
            Catch ex As Exception
                Throw New ValidationErrorException("SQL Error: " & ex.Message)
            End Try

            If dbDT.Rows.Count = 1 Then
                Document_Type.IndexField.Value = dbDT.Rows(0).Item(0).ToString.Trim
                Exit Sub
            End If

            'Another hard coded sql string with hsi specific code that be reviewed
            sqlQ = New String($"SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) Like Upper('%{Document_Type.IndexField.Value}%') and ITEMTYPEGROUPNUM = '105' Order by ItemTypeName")

            Try
                dbDT = FillDT(sqlQ, dbConStr)
            Catch ex As Exception
                Throw New ValidationErrorException("SQL Error: " & ex.Message)
            End Try

            If dbDT.Rows.Count < 1 Then
                MsgBox("No similar Document Types found.",, "Validation Error")
                Throw New ValidationErrorException("No similar Document Types found.")
            End If

            If dbDT.Rows.Count = 1 Then
                Document_Type.IndexField.Value = dbDT.Rows(0).Item(0).ToString.Trim
                Exit Sub
            End If

            Using dtDlg As New DocTypeDialog
                'Exclusion list as interpreted from SBL
                ' MAY NEED TO ADD SPACE AFTER THE DIGITS TO PREVENT 22#, 31# etc. selections
                For Each dtRow As DataRow In dbDT.Rows
                    Debug.Print("Looking at " & dtRow.Item(0).ToString)
                    If dtRow.Item(0).ToString.Contains("ZZ") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 106") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 107") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 131") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 141") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 143") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 172") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 174") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 178") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 22") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 242A") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 279") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 287") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 31") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 313") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 320") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 321") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 343") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 361") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 403") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 504") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 510") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 519") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 520") Or
                   dtRow.Item(0).ToString.StartsWith("SWIF 613") Then
                        Debug.Print("  Skipping ")
                        'dbDT.Rows.Remove(dtRow)
                    Else
                        dtDlg.cbDocTypes.Items.Add(dtRow.Item(0).ToString)
                    End If
                Next

                dtDlg.Label1.Text = dtDlg.cbDocTypes.Items.Count.ToString & " Valid Matches Found"
                If Not dtDlg.ShowDialog() = Windows.Forms.DialogResult.Cancel Then
                    Document_Type.IndexField.Value = dtDlg.cbDocTypes.SelectedText
                End If
            End Using


        End Sub

        Private Sub Document_Date_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Document_Date.FieldPostProcessing
            Document_Date.IndexField.Value = Format_Date(Document_Date.IndexField.Value)
            If Not IsDate(Document_Date.IndexField.Value) Then
                MsgBox("Invalid Date",, "Validation Error")
                Throw New ValidationErrorException("Invalid Date")
            End If
            'Removed Future Test  11/20/2025
            'If Date.Parse(Document_Date.IndexField.Value) > Now Then
            '    MsgBox("Invalid Date",, "Validation Error")
            '    Throw New ValidationErrorException("Invalid Date")
            'End If
        End Sub

        Private Sub Medical_Flag_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Medical_Flag.FieldPostProcessing
            Medical_Flag.IndexField.Value = Medical_Flag.IndexField.Value.Trim.ToUpper
            If Medical_Flag.IndexField.Value <> "Y" And Medical_Flag.IndexField.Value <> "N" Then
                MsgBox("Please enter 'Y' or 'N' for the Medical Flag",, "Validation Error")
                Throw New ValidationErrorException("Invalid Medical Flag")
            End If
        End Sub




#End Region


#Region "Toolbox"
        Function Format_Date(ByVal TestValue As String) As String
            If String.IsNullOrWhiteSpace(TestValue) Then
                Return String.Empty
            End If
            If IsNumeric(TestValue) Then
                Select Case TestValue.Length
                    Case 6
                        Return DateTime.ParseExact(TestValue, "MMddyy", Nothing).ToString("MM/dd/yyyy")
                    Case 8
                        Return DateTime.ParseExact(TestValue, "MMddyyyy", Nothing).ToString("MM/dd/yyyy")
                    Case Else
                        Return String.Empty
                End Select
            End If
            If IsDate(TestValue) Then
                Return Date.Parse(TestValue).ToString("MM/dd/yyyy")
            End If
            Return String.Empty
        End Function

        Function FillDT(ByVal dbSql As String, ByVal dbConStr As String) As DataTable
            Dim dbDT As New DataTable()
            If bypassDatabase Then Return dbDT
            Using dbConn As New OdbcConnection(dbConStr)
                dbConn.Open()
                Using dbAdapt As New OdbcDataAdapter(dbSql, dbConn)
                    dbAdapt.Fill(dbDT)
                End Using
                dbConn.Close()
            End Using
            Return dbDT
        End Function
#End Region


    End Class
End Namespace
