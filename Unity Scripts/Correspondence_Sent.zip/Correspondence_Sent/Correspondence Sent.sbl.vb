REM ========================================================================
REM
REM   Document Class Script Name: Correspondence Sent
REM
REM
REM ------------------------------------------------------------------------


Option Explicit


REM ========================================================================
REM Numeric validation DLL declarations.
REM ------------------------------------------------------------------------

Declare Function KfxValidateDecimal Lib "KfxValid.dll" _
        (DecimalString As String, ByVal Precision As Integer, _
        ByVal Scale As Integer) As Integer
Declare Function KfxFormatDecimal Lib "KfxValid.dll" _
        (DecimalString As String, ByVal Precision As Integer, _
        ByVal Scale As Integer) As Integer
Declare Function KfxRoundInteger Lib "KfxValid.dll"      (InValue as String, ByRef OutValue as long) as Integer 
Declare Function KfxRoundSmallInteger Lib "KfxValid.dll" (InValue as String, ByRef OutValue as integer) as Integer 
Declare Function KfxValidateDouble Lib "KfxValid.dll" (DoubleString As String) As Integer
Declare Function KfxFormatDouble Lib "KfxValid.dll" (DoubleString As String) As Integer
Declare Function KfxValidateReal Lib "KfxValid.dll" (RealString As String) As Integer
Declare Function KfxFormatReal Lib "KfxValid.dll" (RealString As String) As Integer

REM ========================================================================
REM Return codes shared with Indexing Application, do not modify.
REM ------------------------------------------------------------------------

   ' Rejects the current document and moves to the next unprocessed one

const RejectAndSkipDocument= -4

   ' Indicates validation error.  Indexing application displays error msg
   ' and it does not advance to the next field on the indexing form.

const ValidationError      = -3

   ' Indicates validation error.  Indexing application does not display
   ' any error message and it does not advance to the next field on the
   ' indexing form.

const ValidationErrorNoMsg = -2

   ' Indicates fatal error.  Batch is set to error state.

const FatalError           = -1

   ' Indicates successful operation.  If this is returned from an post
   ' index field function, the indexing application advances to the next
   ' field on the form.

const NoError              = 0

   ' Indicates that the values in the document should all be saved
   ' and the indexing applications should advance to the next
   ' document.  WARNING:  This feature should be used with caution
   ' as no validation will be performed on any of the subsequent
   ' index fields for the current document, including ensuring
   ' that an index field marked as 'required' may be left blank.
   ' NOTE: The DocPostProcess function is still called after a
   ' SaveAndSkip 

const SaveAndSkipDocument  = 1

   ' When returned from the pre-field trigger, this code
   ' causes the same behavior as if the tab (or enter) key was pressed
   ' in the current field.

const SaveAndSkipField     = 2

   ' Indicates that the corresponding default script behavior will be executed after
   ' the current custom script function.

const NoOperation          = 3



REM ========================================================================
REM Misc variables for script customization.
REM ------------------------------------------------------------------------

   ' The default behavior is for the indexing application to call the
   ' pre-focus-document and post-focus-document functions only for those
   ' documents that the user interacts with.  So, when a suspended batch
   ' (partially indexed) is again processed, pre and post focus are called
   ' only for the documents that the user processes.  The already indexed
   ' documents are skipped.
   ' For the case where the script is accumulating, it may be desirable
   ' to call the document pre and post focus functions for all documents
   ' including those that have been previously indexed.  If this is the
   ' case, the variable KfxLoadAllProcessedValues must be set to YES else
   ' don't define it or set it to NO.

Global const KfxLoadAllProcessedValues = "NO"

   ' Must be present!   Indicates type of operation being done, index or
   ' index verify.

Global KfxOperation As String
         
   ' If present, this read-only variable is set to the name of the batch
   ' being processed.

Dim KfxBatchName As String

   ' If present, this read-only variable is set to the id of the batch
   ' being processed.

Dim KfxBatchId As String

   ' Uncomment the definition below if the Batch Class Id associated
   ' with the batch being processed is required.

'Dim KfxBatchClassId As String

   ' If present, this read-only variable is set to the name of the
   ' document class associated with the batch being processed.

Dim KfxClassName As String

   ' Uncomment the definition below if the Document Class Id associated
   ' with the batch being processed is required.

'Dim KfxDocClassId As String
   
   ' Uncomment the definition below if the script is to have 
   ' access to the page image associated with the current index field.  

' Dim KfxPageFile As String

   ' Uncomment the definition below if the script wants to change
   ' the error messages (and thus the document notes and batch history
   ' entries) produced when returning FatalError or RejectAndSkip
   ' from any function (except the format calls)

' Dim KfxErrorMessage As String

Global Connection as Long
Global errors(1 to 3, 1 to 10) as Variant
Global KfxDocument_Type As String


Global KfxClaimant_Name As String
Global KfxSSN As String
Global KfxPolicy_Number As String

REM ========================================================================
REM Index fields processed by pre, post, or format procedures must be
REM defined above before any of the functions that actually use them.
REM ------------------------------------------------------------------------


REM ========================================================================
REM Function handling initialization for this module.
REM This function is called after the user opens a batch.  The function is
REM called once per batch and is called and before any other function in
REM this module.
REM ------------------------------------------------------------------------

Function KfxLoadValidation ( VerifyBatch As Integer, _
              NumberOfDocsInBatch As Integer ) As Integer
   On Error GoTo Failure

   If (VerifyBatch <> 0) Then
      KfxOperation = "Verify"
   Else
      KfxOperation = "Index"
   End If
   
Rem // Open the database with the ODBC string.
      
     Connection=SQLOpen("DSN=SWIFOBP0; UID=HSI; pwd=wstinol")
     
     If Connection < 0 then
         SQLError destination:=errors
         msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "ODBC Connection Failed"
         goto failure
     End if    

Rem // End 
  
   KfxLoadValidation = NoError
   Exit Function

Failure:
   KfxLoadValidation = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling termination of this module.
REM This function is called upon end of processing for the batch.  The
REM function is called once per batch and is the last function to be
REM called from this module.
REM ------------------------------------------------------------------------

Function KfxUnloadValidation ( ) As Integer
   On Error GoTo Failure

Rem // Close the ODBC Connection once all documents have been indexed
   Dim Result as Integer
   Result=SQLClose(Connection)
   
   KfxUnloadValidation = NoError
   Exit Function

Failure:
   KfxUnloadValidation = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling document pre index processing.
REM This function can return NoError, FatalError, or SaveAndSkipDocument. 
REM
REM NOTE:
REM   We recommend not returning SaveAndSkipDocument if the document
REM   has already been processed.  In the case where all the documents
REM   in the batch have been processed (indexed), returning
REM   SaveAndSkipDocument will prevent the indexing application from
REM   stopping on any document in the batch.
REM ------------------------------------------------------------------------

Function KfxDocPreProcess ( Id As Long, NumberOfPages As Integer, _
             AlreadyProcessed As Integer) As Integer
   On Error GoTo Failure

   If (AlreadyProcessed) Then
      KfxDocPreProcess = NoError
      Exit Function
   End If

   KfxDocPreProcess = NoError
   Exit Function

Failure:
   KfxDocPreProcess = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling document post index processing.
REM This function can return NoError or FatalError.
REM ------------------------------------------------------------------------

Function KfxDocPostProcess ( Id As Long, DataAccepted As Integer) As Integer
   On Error GoTo Failure

   If KfxDocument_Type = "LIBC 9 - Medical Report Form" then
      KfxDocument_Type = "M005 - Medical Documents"
   End If

   Dim Operation As String                ' example code
   If (DataAccepted = 1) Then             ' example code
      Operation = "Requested Save Index Data" ' example code
   Else                             ' example code
      Operation = "Cancelled Save Index Data" ' example code
   End If                              ' example code

   KfxDocPostProcess = NoError
   Exit Function

Failure:
   KfxDocPostProcess = FatalError
   Exit Function
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLClaim_Number As String

                     ' Index field value.

Global KfxClaim_Number As String

                     '===============================================
                                                        '===== SQL_CHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Claim_Number default value: ""
                     '-----------------------------------------------
Function PreClaim_Number() As Integer
   On Error GoTo Failure
   PreClaim_Number = NoError
   Exit Function
Failure:
   PreClaim_Number = FatalError
   Exit Function
End Function
                     '----- Claim_Number validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostClaim_Number( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
        If ( Len(EnteredValue) > MaxLength ) Then 
           msgbox "The Claim Number entered is too long." ,, "Please re-enter Claim Number."
           GoTo Failure
        End If
 
 Rem // Pad the Entered Value with zeroes to 8 digits
 
   If Len(EnteredValue) = 7 Then
      EnteredValue = "0" + EnteredValue
   Else
      If Len(EnteredValue) = 6 Then
         EnteredValue = "00" + EnteredValue
      Else 
         If Len(EnteredValue) = 5 Then
            EnteredValue = "000" + EnteredValue
         Else 
            If Len(EnteredValue) = 4 Then
               EnteredValue = "0000" + EnteredValue
            Else
               If Len(EnteredValue) = 3 Then
                  EnteredValue = "00000" + EnteredValue
               End If
            End If
         End If
      End If
   End If
     
 Rem // Based on Claim Number, retrieve the Claimant and SSN
  
   Dim SQL as Variant
   Dim Result as integer
   Dim ClaimArray(1 to 3, 1 to 1) as Variant
   
   SQL = "SELECT KS259, KS118, KS181 FROM HSI.KEYSETDATA146 WHERE KS102 = '" & EnteredValue & "'"
      
   Result = SQLExecQuery(Connection, SQL)
  
   If Result <= 0 then
     SQLError destination:=errors
     msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
     goto failure
   End if

   Result = SQLRetrieve(Connection, ClaimArray())   
     
   If Result = 0 then
      SQLError destination:=errors
      msgbox "The Claim Number entered is not on file." ,, "Claim Not Found" 
      goto failure
   End if 
   
 
   KfxClaimant_Name = ClaimArray(1,1)
   KfxSSN           = ClaimArray(2,1)
   KfxPolicy_Number = ClaimArray(3,1)
 
   
   If KfxClaimant_Name = "" then
      msgbox "Claimant Name is blank.  Please Reject this document.",,"Invalid Data"
      goto failure
   End If
   
 Rem // Pop up a window containing Claimant and Tax ID for entered Claim Number
   
   If KfxOperation = "Verify" Then
      dim msgtxt as string
      msgtxt = "Claimant: "& KfxClaimant_Name &""
      msgtxt = msgtxt + Chr(10) + Chr(10)
      msgtxt = msgtxt + "SSN: "
      msgtxt = msgtxt + ""& KfxSSN &""      
rem      msgbox msgtxt,, "Claimant Info"
   End If 
   
   KfxClaim_Number  = EnteredValue
   
   PostClaim_Number = NoError
   Exit Function
Failure:
   PostClaim_Number = ValidationError
   Exit Function
End Function
                     '----- Claim_Number format
                     '-----------------------------------------------
Function FmtClaim_Number() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtClaim_Number = KfxClaim_Number
   Exit Function
Failure:
   FmtClaim_Number = KfxClaim_Number
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLClaimant_Name As String

                     ' Index field value.


                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Claimant_Name default value: ""
                     '-----------------------------------------------
Function PreClaimant_Name() As Integer
   On Error GoTo Failure
 
   if kfxoperation = "Index" then
   PreClaimant_Name = SAVEANDSKIPFIELD
   end if
    
   'PreClaimant_Name = NoError
   Exit Function
Failure:
   PreClaimant_Name = FatalError
   Exit Function
End Function
                     '----- Claimant_Name validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostClaimant_Name( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxClaimant_Name = EnteredValue

   PostClaimant_Name = NoError
   Exit Function
Failure:
   PostClaimant_Name = ValidationError
   Exit Function
End Function
                     '----- Claimant_Name format
                     '-----------------------------------------------
Function FmtClaimant_Name() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtClaimant_Name = KfxClaimant_Name
   Exit Function
Failure:
   FmtClaimant_Name = KfxClaimant_Name
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLSSN As String

                     ' Index field value.


                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- SSN default value: ""
                     '-----------------------------------------------
Function PreSSN() As Integer
   On Error GoTo Failure
   
   PreSSN = SAVEANDSKIPFIELD
   'PreSSN = NoError
   Exit Function
Failure:
   PreSSN = FatalError
   Exit Function
End Function
                     '----- SSN validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostSSN( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxSSN = EnteredValue
   PostSSN = NoError
   Exit Function
Failure:
   PostSSN = ValidationError
   Exit Function
End Function
                     '----- SSN format
                     '-----------------------------------------------
Function FmtSSN() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtSSN = KfxSSN
   Exit Function
Failure:
   FmtSSN = KfxSSN
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDocument_Type As String

                     ' Index field value.


                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Document_Type default value: ""
                     '-----------------------------------------------
Function PreDocument_Type() As Integer
   On Error GoTo Failure
   PreDocument_Type = NoError
   Exit Function
Failure:
   PreDocument_Type = FatalError
   Exit Function
End Function
                     '----- Document_Type validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDocument_Type( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
      
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   If EnteredValue = "" Then
      msgbox "Please enter a Document Type.",,"Document Type"
      goto failure
   End If
   
   Dim SQL as Variant
   Dim Result as integer
   Dim DocTypeArray(1 to 1, 1 to 500) as Variant
   Dim SearchString as String
 
 
   Rem //Before anything, check quick enter items.  If match, fill index.
   
   If EnteredValue = "mm" Then
       KfxDocument_Type = "Medical Management Documents"
       PostDocument_Type = NoError
       Exit Function
   ElseIf EnteredValue = "voc" Then
       KfxDocument_Type = "Vocational Rehabilitation Documents"
       PostDocument_Type = NoError
       Exit Function
   ElseIF EnteredValue = "srv" Then
       KfxDocument_Type = "Surveillance/Investigation Documents"
       PostDocument_Type = NoError
       Exit Function
   ElseIf EnteredValue = "ire" Then
       KfxDocument_Type = "IRE/Impairment Rating Evaluation"
       PostDocument_Type = NoError
       Exit Function    
   End If
    
   Rem // First check for an exact match for the Entered Value.  If exact match, fill the 
   Rem // index field and move on.

     SQL = "SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) = Upper('" & EnteredValue & "') and ITEMTYPEGROUPNUM = '105'"
     Result = SQLExecQuery(Connection, SQL)
  
     If Result <= 0 then
       SQLError destination:=errors
       msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
       goto failure
     End if

     Result = SQLRetrieve(Connection, DocTypeArray())   
     
     If Result = 1 then
       KfxDocument_Type = trim(DocTypeArray(1,1))
       PostDocument_Type = NoError
       Exit Function
     End if 
   
   Rem // Build List of Claims Documents based on the value entered by the user.  The SQL result set will 
   Rem // include records that contain the entered value (wildcard search) 
   
     SearchString = "%" + EnteredValue + "%"
     SearchString = UCase(SearchString)   
     SQL = "SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) Like '" & SearchString & "' and ITEMTYPEGROUPNUM = '105' ORDER BY ITEMTYPENAME"
     
     Result = SQLExecQuery(Connection, SQL)
  
     If Result <= 0 then
       SQLError destination:=errors
       msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
       goto failure
     End if

     Result = SQLRetrieve(Connection, DocTypeArray())   
     
     If Result = 0 then
        SQLError destination:=errors
        msgbox "No similar Document Types Found." ,, "No Document Types Found" 
        goto failure
     End if 
   
     If Result = 1 then
       KfxDocument_Type = trim(DocTypeArray(1,1))
       PostDocument_Type = NoError
       Exit Function
     End if 
     
     dim size as integer
     size = Result 
     ReDim DocTypeDlgArray(size) as String
      
     dim count as integer
     dim x     as integer
     count = 1     
     x     = 1
     Do    
      If Mid(DocTypeArray(1,count), 1, 2) <> "ZZ" Then
         
         If  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 106" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 107" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 131" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 141" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 143" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 172" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 174" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 178" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 7) = "SWIF 22" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 9) = "SWIF 242A" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 279" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 287" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 7) = "SWIF 31" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 313" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 320" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 321" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 343" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 361" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 403" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 504" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 510" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 519" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 520" Then
         ElseIf  Mid(DocTypeArray(1,count), 1, 8) = "SWIF 613" Then
         Else
         
            DocTypeDlgArray(x - 1) = DocTypeArray(1,count)
            x =  x + 1
            
         End If
      End If
      count = count + 1
     Loop Until count > size
     
     Begin Dialog DOCTYPEDIALOG 95, 7, 249, 164, "Document Type Selection"
        ListBox  0, 15, 248, 123, DocTypeDlgArray() , .ListBox1
        OkButton  17, 142, 42, 14
        PushButton  79, 142, 42, 14, "Cancel", .Cancel
        Text  3, 2, 131, 9, "Document Type"
     End Dialog
 
     Dim Res as integer
     Dim DisplayDialog as DOCTYPEDIALOG
     Res = dialog(DisplayDialog) 
     
     If Res = -1 then
       KfxDocument_Type = trim(DocTypeDlgArray(DisplayDialog.ListBox1))
     Else
       Goto Failure
     End If  
  
   PostDocument_Type = NoError
   Exit Function
Failure:
   PostDocument_Type = ValidationError
   Exit Function
End Function
                     '----- Document_Type format
                     '-----------------------------------------------
Function FmtDocument_Type() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDocument_Type = KfxDocument_Type
   Exit Function
Failure:
   FmtDocument_Type = KfxDocument_Type
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDocument_Date As String

                     ' Index field value.

Global KfxDocument_Date As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Document_Date default value: ""
                     '-----------------------------------------------
Function PreDocument_Date() As Integer
   On Error GoTo Failure
   PreDocument_Date = NoError
   Exit Function
Failure:
   PreDocument_Date = FatalError
   Exit Function
End Function
                     '----- Document_Date validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDocument_Date( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   dim tempmm as string
   dim tempdd as string
   dim tempyyyy as string
   
   If Len(EnteredValue) = 6 Then
      tempmm = Mid(EnteredValue,1,2)
      tempdd = Mid(EnteredValue,3,2)
      tempyyyy = Mid(EnteredValue,5,2)
      If tempyyyy > "25" Then
        tempyyyy = "19" + tempyyyy
      else
         tempyyyy = "20" + tempyyyy
      End If
   Else
      If Len(EnteredValue) = 8 Then 
         tempmm = Mid(EnteredValue,1,2)
         tempdd = Mid(EnteredValue,3,2)
         tempyyyy = Mid(EnteredValue,5,4)
      Else
         If Len(EnteredValue) = 10 Then
            tempmm = Mid(EnteredValue,1,2)
            tempdd = Mid(EnteredValue,4,2)
            tempyyyy = Mid(EnteredValue,7,4)
         Else   
            msgbox "Invalid Date Format" ,, "Invalid Data"
            Goto Failure
         End If   
      End If
   End If
   
   EnteredValue = tempmm + "/" + tempdd + "/" + tempyyyy
   
   If Not IsDate(EnteredValue) Then
      msgbox "Invalid Date Format" ,, "Invalid Data"
      Goto Failure
   End If
   
   KfxDocument_Date = EnteredValue
   PostDocument_Date = NoError
   Exit Function
Failure:
   PostDocument_Date = ValidationError
   Exit Function
End Function
                     '----- Document_Date format
                     '-----------------------------------------------
Function FmtDocument_Date() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDocument_Date = KfxDocument_Date
   Exit Function
Failure:
   FmtDocument_Date = KfxDocument_Date
End Function


REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLMedical_Flag As String

                     ' Index field value.

Global KfxMedical_Flag As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Medical_Flag default value: ""
                     '-----------------------------------------------
Function PreMedical_Flag() As Integer
   On Error GoTo Failure
   PreMedical_Flag = NoError
   Exit Function
Failure:
   PreMedical_Flag = FatalError
   Exit Function
End Function
                     '----- Medical_Flag validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostMedical_Flag( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   EnteredValue = UCase(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   If EnteredValue <> "Y" and EnteredValue <> "N" Then
      msgbox "Please Enter 'Y' or 'N' for the Medical Flag" ,, "Invalid Data"
      Goto Failure
   End If
   
   KfxMedical_Flag = EnteredValue
   PostMedical_Flag = NoError
   Exit Function
Failure:
   PostMedical_Flag = ValidationError
   Exit Function
End Function
                     '----- Medical_Flag format
                     '-----------------------------------------------
Function FmtMedical_Flag() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtMedical_Flag = KfxMedical_Flag
   Exit Function
Failure:
   FmtMedical_Flag = KfxMedical_Flag
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLPolicy_Number As String

                     ' Index field value.



                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Policy_Number default value: ""
                     '-----------------------------------------------
Function PrePolicy_Number() As Integer
   On Error GoTo Failure
   PrePolicy_Number = NoError
   Exit Function
Failure:
   PrePolicy_Number = FatalError
   Exit Function
End Function
                     '----- Policy_Number validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostPolicy_Number( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxPolicy_Number = EnteredValue
   PostPolicy_Number = NoError
   Exit Function
Failure:
   PostPolicy_Number = ValidationError
   Exit Function
End Function
                     '----- Policy_Number format
                     '-----------------------------------------------
Function FmtPolicy_Number() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtPolicy_Number = KfxPolicy_Number
   Exit Function
Failure:
   FmtPolicy_Number = KfxPolicy_Number
End Function


REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLFPIA As String

                     ' Index field value.

Global KfxFPIA As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- FPIA default value: ""
                     '-----------------------------------------------
Function PreFPIA() As Integer
   On Error GoTo Failure
   PreFPIA = NoError
   Exit Function
Failure:
   PreFPIA = FatalError
   Exit Function
End Function
                     '----- FPIA validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostFPIA( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxFPIA = EnteredValue
   PostFPIA = NoError
   Exit Function
Failure:
   PostFPIA = ValidationError
   Exit Function
End Function
                     '----- FPIA format
                     '-----------------------------------------------
Function FmtFPIA() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtFPIA = KfxFPIA
   Exit Function
Failure:
   FmtFPIA = KfxFPIA
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDTN As String

                     ' Index field value.

Global KfxDTN As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- DTN default value: ""
                     '-----------------------------------------------
Function PreDTN() As Integer
   On Error GoTo Failure
   PreDTN = NoError
   Exit Function
Failure:
   PreDTN = FatalError
   Exit Function
End Function
                     '----- DTN validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDTN( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxDTN = EnteredValue
   PostDTN = NoError
   Exit Function
Failure:
   PostDTN = ValidationError
   Exit Function
End Function
                     '----- DTN format
                     '-----------------------------------------------
Function FmtDTN() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDTN = KfxDTN
   Exit Function
Failure:
   FmtDTN = KfxDTN
End Function

Sub Main
dim Result as Integer
Result = KfxLoadValidation(1,0)
Result = PostDocument_Type("SWIF",50)
'Result = PostClaim_Number("11429210",12)
'Result = PostDocument_Date("020205", 10)
Result = KfxDocPostProcess ( 1, 1)
End Sub
