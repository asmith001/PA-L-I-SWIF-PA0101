Imports Kofax.AscentCapture.NetScripting
Imports Kofax.Capture.CaptureModule.InteropServices
Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data
Imports System.Data.Odbc
Imports Kofax.AscentCapture.Scripting.PreFieldEventArgs
Imports Claim_Document.DocTypeDialog
' 2025      Original Development        Fred Bullmer
'***************************************************************
'11/20/2025 FCB         Improvements per UAT
'
'
'

Namespace WF_Prescription_Hoover_Bills
	
	<SuppressFieldEventsOnDocClose(false)>  _
	Public Class WF_Prescription_Hoover_Bills
		Inherits DocumentValidationScript

#Region "Document Fields"
		<IndexFieldVariableAttribute("Claim Number")> Dim WithEvents Claim_Number As FieldScript
		<IndexFieldVariableAttribute("Claimant Name")> Dim WithEvents Claimant_Name As FieldScript
		<IndexFieldVariableAttribute("SSN")> Dim WithEvents SSN As FieldScript
		<IndexFieldVariableAttribute("Document Type")> Dim WithEvents Document_Type As FieldScript
		<IndexFieldVariableAttribute("Document Date")> Dim WithEvents Document_Date As FieldScript
		<IndexFieldVariableAttribute("Medical Flag")> Dim WithEvents Medical_Flag As FieldScript
		<IndexFieldVariableAttribute("Document Received Date")> Dim WithEvents Document_Received_Date As FieldScript
		<IndexFieldVariableAttribute("Policy Number")> Dim WithEvents Policy_Number As FieldScript
		<IndexFieldVariableAttribute("DTN")> Dim WithEvents DTN As FieldScript
#End Region

		Dim dbConStr As String = String.Empty       'Obtain from hidden Batch field
		Dim bypassDatabase As Boolean = False       'set if not found
		Dim dbDT As DataTable = New DataTable       'set as result of query
		Dim sqlQ As String = String.Empty           'current sql query

		Dim valFlag As Boolean = False

#Region "Batch Handling"

		Sub New(ByVal bIsValidation As Boolean, ByVal strUserID As String, ByVal strLocaleName As String)
			MyBase.New(bIsValidation, strUserID, strLocaleName)
		End Sub

		Private Sub WF_Prescription_Hoover_Bills_BatchLoading(sender As Object, e As BatchEventArgs) Handles Me.BatchLoading
			Try         'aquire external db connection string
				dbConStr = e.Batch.BatchFields.Item("DBConStr").Value
				If dbConStr.Length < 1 Then bypassDatabase = True
			Catch ex As Exception
				Throw New FatalErrorException("Please add 'DBConStr' as a hidden Batch Field")
			End Try
		End Sub
		Private Sub WF_Prescription_Hoover_Bills_DocumentPreProcessing(sender As Object, e As PreDocumentEventArgs) Handles Me.DocumentPreProcessing
			'use to skip on initial indexing but not if already processed
			valFlag = e.AlreadyProcessed
		End Sub
		Private Sub WF_Prescription_Hoover_Bills_DocumentPostProcessing(sender As Object, e As PostDocumentEventArgs) Handles Me.DocumentPostProcessing
			Try
				Select Case Document_Type.IndexField.Value
					Case "LIBC 9 - Medical Report Form"
						Document_Type.IndexField.Value = "M005 - Medical Documents"
				End Select
			Catch ex As Exception
			End Try
		End Sub

#End Region

#Region "Field Handling"
		Private Sub Claim_Number_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Claim_Number.FieldPostProcessing
			If String.IsNullOrWhiteSpace(Claim_Number.IndexField.Value) Then
				Throw New ValidationErrorException("Claim Number is empty")
			End If
			If Claim_Number.IndexField.Value = "1" Then
				Claimant_Name.IndexField.Value = "1"
				SSN.IndexField.Value = "1"
				Policy_Number.IndexField.Value = "1"
				Exit Sub
			End If
			'Added length test 11/20/2025
			If Claim_Number.IndexField.Value.Length < 8 Then
				Try
					Claim_Number.IndexField.Value = Int32.Parse(Claim_Number.IndexField.Value.Trim).ToString("00000000")
				Catch ex As Exception
					Throw New ValidationErrorException("Claim Number is invalid")
				End Try
			End If
			'THIS NEEDS TO BE REPLACED WITH A VIEW OR EXTERNAL HIDDEN BATCH FIELD
			sqlQ = New String($"SELECT KS259, KS118, KS181 FROM HSI.KEYSETDATA146 WHERE KS102 = '{Claim_Number.IndexField.Value}'")

			Try
				dbDT = FillDT(sqlQ, dbConStr)
			Catch ex As Exception
				MsgBox("SQL Error searching for claim: " & vbCrLf & ex.Message, , "Validation Error")
				Throw New ValidationErrorException(ex.Message)
			End Try

			If dbDT.Rows.Count < 1 Then
				MsgBox("The Claim Number entered is not on file.", , "Validation Error")
				Throw New ValidationErrorException("The Claim Number entered is not on file.")
			End If

			If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(0)) Then
				Claimant_Name.IndexField.Value = dbDT.Rows(0).Item(0).ToString().Trim()
			Else
				MsgBox("Claimant Name is blank.  Please Reject this document.",, "Validation Error")
			End If
			If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(1)) Then
				SSN.IndexField.Value = dbDT.Rows(0).Item(1).ToString().Trim()
			End If
			If Not String.IsNullOrWhiteSpace(dbDT.Rows(0).Item(2)) Then
				Policy_Number.IndexField.Value = dbDT.Rows(0).Item(2).ToString().Trim()
			End If
		End Sub

		Private Sub Document_Type_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Document_Type.FieldPostProcessing
			If String.IsNullOrWhiteSpace(Document_Type.IndexField.Value) Then
				'MsgBox("Please enter a Document Type.",, "Validation Error")
				'Throw New ValidationErrorException("Missing Document Type")

				Document_Type.IndexField.Value = Document_Type.IndexField.Value.Trim

				Using dtDlg As New DocTypeDialog
					dtDlg.cbDocTypes.Items.Add("HCFA 1500 - Part B Billings")
					dtDlg.cbDocTypes.Items.Add("M009 - Prescription Bills")
					dtDlg.cbDocTypes.Items.Add("Miscellaneous Bills")
					dtDlg.cbDocTypes.Items.Add("UB 92 - Part A Billings (Medical)")

					dtDlg.Label1.Text = dtDlg.cbDocTypes.Items.Count.ToString & " Valid Matches Found"
					If Not dtDlg.ShowDialog() = Windows.Forms.DialogResult.Cancel Then
						Document_Type.IndexField.Value = dtDlg.cbDocTypes.SelectedText
					End If
				End Using
			End If

			REM // Build List of Documents based on the value entered by the user.  The SQL result set will 
			REM // include records that contain the entered value (wildcard search)

			'Another hard coded sql string with hsi specific code that be reviewed
			sqlQ = $"SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) Like '%{Document_Type.IndexField.Value}%' and ITEMTYPEGROUPNUM = '105' and ITEMTYPENAME in ('HCFA 1500 - Part B Billings','M009 - Prescription Bills','Miscellaneous Bills','UB 92 - Part A Billings (Medical)') ORDER BY ITEMTYPENAME"

			Try
				dbDT = FillDT(sqlQ, dbConStr)
			Catch ex As Exception
				Throw New ValidationErrorException("SQL Error: " & ex.Message)
			End Try

			If dbDT.Rows.Count < 1 Then
				MsgBox("No similar Document Types found.",, "Validation Error")
				Throw New ValidationErrorException("No similar Document Types found.")
			End If

			If dbDT.Rows.Count = 1 Then
				Document_Type.IndexField.Value = dbDT.Rows(0).Item(0).ToString.Trim
				Exit Sub
			End If

			If dbDT.Rows.Count > 0 Then
				Using dtDlg As New DocTypeDialog
					dtDlg.cbDocTypes.Items.Add("HCFA 1500 - Part B Billings")
					dtDlg.cbDocTypes.Items.Add("M009 - Prescription Bills")
					dtDlg.cbDocTypes.Items.Add("Miscellaneous Bills")
					dtDlg.cbDocTypes.Items.Add("UB 92 - Part A Billings (Medical)")

					dtDlg.Label1.Text = dtDlg.cbDocTypes.Items.Count.ToString & " Valid Matches Found"
					If Not dtDlg.ShowDialog() = Windows.Forms.DialogResult.Cancel Then
						Document_Type.IndexField.Value = dtDlg.cbDocTypes.SelectedText
					End If
				End Using
			End If

		End Sub

		Private Sub Document_Date_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Document_Date.FieldPostProcessing
			Document_Date.IndexField.Value = Format_Date(Document_Date.IndexField.Value)
			If Not IsDate(Document_Date.IndexField.Value) Then
				MsgBox("Invalid Date",, "Validation Error")
				Throw New ValidationErrorException("Invalid Date")
			End If
			'Removed Future Test  11/20/2025
			'If Date.Parse(Document_Date.IndexField.Value) > Now Then
			'    MsgBox("Invalid Date",, "Validation Error")
			'    Throw New ValidationErrorException("Invalid Date")
			'End If
		End Sub

		Private Sub Medical_Flag_FieldPostProcessing(sender As Object, e As PostFieldEventArgs) Handles Medical_Flag.FieldPostProcessing
			Medical_Flag.IndexField.Value = Medical_Flag.IndexField.Value.Trim.ToUpper
			If Medical_Flag.IndexField.Value <> "Y" And Medical_Flag.IndexField.Value <> "N" Then
				MsgBox("Please enter 'Y' or 'N' for the Medical Flag",, "Validation Error")
				Throw New ValidationErrorException("Invalid Medical Flag")
			End If
		End Sub

#End Region

#Region "Toolbox"

		Function Format_Date(ByVal TestValue As String) As String
			If String.IsNullOrWhiteSpace(TestValue) Then
				Return String.Empty
			End If
			If IsNumeric(TestValue) Then
				Select Case TestValue.Length
					Case 6
						Return DateTime.ParseExact(TestValue, "MMddyy", Nothing).ToString("MM/dd/yyyy")
					Case 8
						Return DateTime.ParseExact(TestValue, "MMddyyyy", Nothing).ToString("MM/dd/yyyy")
					Case Else
						Return String.Empty
				End Select
			End If
			If IsDate(TestValue) Then
				Return Date.Parse(TestValue).ToString("MM/dd/yyyy")
			End If
			Return String.Empty
		End Function

		Function FillDT(ByVal dbSql As String, ByVal dbConStr As String) As DataTable
			Dim dbDT As New DataTable()
			If bypassDatabase Then Return dbDT
			Using dbConn As New OdbcConnection(dbConStr)
				dbConn.Open()
				Using dbAdapt As New OdbcDataAdapter(dbSql, dbConn)
					dbAdapt.Fill(dbDT)
				End Using
				dbConn.Close()
			End Using
			Return dbDT
		End Function
#End Region


	End Class
End Namespace
