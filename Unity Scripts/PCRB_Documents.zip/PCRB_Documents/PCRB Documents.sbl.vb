REM ========================================================================
REM
REM   Document Class Script Name: PCRB Documents
REM
REM
REM ------------------------------------------------------------------------

Option Explicit


REM ========================================================================
REM Numeric validation DLL declarations.
REM ------------------------------------------------------------------------

Declare Function KfxValidateDecimal Lib "KfxValid.dll" _
        (DecimalString As String, ByVal Precision As Integer, _
        ByVal Scale As Integer) As Integer
Declare Function KfxFormatDecimal Lib "KfxValid.dll" _
        (DecimalString As String, ByVal Precision As Integer, _
        ByVal Scale As Integer) As Integer
Declare Function KfxRoundInteger Lib "KfxValid.dll"      (InValue as String, ByRef OutValue as long) as Integer 
Declare Function KfxRoundSmallInteger Lib "KfxValid.dll" (InValue as String, ByRef OutValue as integer) as Integer 
Declare Function KfxValidateDouble Lib "KfxValid.dll" (DoubleString As String) As Integer
Declare Function KfxFormatDouble Lib "KfxValid.dll" (DoubleString As String) As Integer
Declare Function KfxValidateReal Lib "KfxValid.dll" (RealString As String) As Integer
Declare Function KfxFormatReal Lib "KfxValid.dll" (RealString As String) As Integer

REM ========================================================================
REM Return codes shared with Indexing Application, do not modify.
REM ------------------------------------------------------------------------

   ' Rejects the current document and moves to the next unprocessed one

const RejectAndSkipDocument= -4

   ' Indicates validation error.  Indexing application displays error msg
   ' and it does not advance to the next field on the indexing form.

const ValidationError      = -3

   ' Indicates validation error.  Indexing application does not display
   ' any error message and it does not advance to the next field on the
   ' indexing form.

const ValidationErrorNoMsg = -2

   ' Indicates fatal error.  Batch is set to error state.

const FatalError           = -1

   ' Indicates successful operation.  If this is returned from an post
   ' index field function, the indexing application advances to the next
   ' field on the form.

const NoError              = 0

   ' Indicates that the values in the document should all be saved
   ' and the indexing applications should advance to the next
   ' document.  WARNING:  This feature should be used with caution
   ' as no validation will be performed on any of the subsequent
   ' index fields for the current document, including ensuring
   ' that an index field marked as 'required' may be left blank.
   ' NOTE: The DocPostProcess function is still called after a
   ' SaveAndSkip 

const SaveAndSkipDocument  = 1

   ' When returned from the pre-field trigger, this code
   ' causes the same behavior as if the tab (or enter) key was pressed
   ' in the current field.

const SaveAndSkipField     = 2

   ' Indicates that the corresponding default script behavior will be executed after
   ' the current custom script function.

const NoOperation          = 3



REM ========================================================================
REM Misc variables for script customization.
REM ------------------------------------------------------------------------

   ' The default behavior is for the indexing application to call the
   ' pre-focus-document and post-focus-document functions only for those
   ' documents that the user interacts with.  So, when a suspended batch
   ' (partially indexed) is again processed, pre and post focus are called
   ' only for the documents that the user processes.  The already indexed
   ' documents are skipped.
   ' For the case where the script is accumulating, it may be desirable
   ' to call the document pre and post focus functions for all documents
   ' including those that have been previously indexed.  If this is the
   ' case, the variable KfxLoadAllProcessedValues must be set to YES else
   ' don't define it or set it to NO.

Global const KfxLoadAllProcessedValues = "NO"

   ' Must be present!   Indicates type of operation being done, index or
   ' index verify.

Global KfxOperation As String
         
   ' If present, this read-only variable is set to the name of the batch
   ' being processed.

Dim KfxBatchName As String

   ' If present, this read-only variable is set to the id of the batch
   ' being processed.

Dim KfxBatchId As String

   ' Uncomment the definition below if the Batch Class Id associated
   ' with the batch being processed is required.

'Dim KfxBatchClassId As String

   ' If present, this read-only variable is set to the name of the
   ' document class associated with the batch being processed.

Dim KfxClaTax_Idame As String

   ' Uncomment the definition below if the Document Class Id associated
   ' with the batch being processed is required.

'Dim KfxDocClassId As String
   
   ' Uncomment the definition below if the script is to have 
   ' access to the page image associated with the current index field.  

' Dim KfxPageFile As String

   ' Uncomment the definition below if the script wants to change
   ' the error messages (and thus the document notes and batch history
   ' entries) produced when returning FatalError or RejectAndSkip
   ' from any function (except the format calls)

' Dim KfxErrorMessage As String

Global Connection as Long
Global errors(1 to 3, 1 to 10) as Variant


Global KfxInsured_Name As String
Global KfxTax_Id As String

REM ========================================================================
REM Index fields processed by pre, post, or format procedures must be
REM defined above before any of the functions that actually use them.
REM ------------------------------------------------------------------------


REM ========================================================================
REM Function handling initialization for this module.
REM This function is called after the user opens a batch.  The function is
REM called once per batch and is called and before any other function in
REM this module.
REM ------------------------------------------------------------------------

Function KfxLoadValidation ( VerifyBatch As Integer, _
              NumberOfDocsInBatch As Integer ) As Integer
   On Error GoTo Failure

   If (VerifyBatch <> 0) Then
      KfxOperation = "Verify"
   Else
      KfxOperation = "Index"
   End If
   
Rem // Open the database with the ODBC string.
      
     Connection=SQLOpen("DSN=SWIFOBP0;UID=jmcgann;PWD=jmcgann")
     
     If Connection < 0 then
         SQLError destination:=errors
         msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "ODBC Connection Failed"
         goto failure
     End if    

Rem // End 
  
   KfxLoadValidation = NoError
   Exit Function

Failure:
   KfxLoadValidation = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling termination of this module.
REM This function is called upon end of processing for the batch.  The
REM function is called once per batch and is the last function to be
REM called from this module.
REM ------------------------------------------------------------------------

Function KfxUnloadValidation ( ) As Integer
   On Error GoTo Failure

Rem // Close the ODBC Connection once all documents have been indexed
   Dim Result as Integer
   Result=SQLClose(Connection)
   
   KfxUnloadValidation = NoError
   Exit Function

Failure:
   KfxUnloadValidation = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling document pre index processing.
REM This function can return NoError, FatalError, or SaveAndSkipDocument. 
REM
REM NOTE:
REM   We recommend not returning SaveAndSkipDocument if the document
REM   has already been processed.  In the case where all the documents
REM   in the batch have been processed (indexed), returning
REM   SaveAndSkipDocument will prevent the indexing application from
REM   stopping on any document in the batch.
REM ------------------------------------------------------------------------

Function KfxDocPreProcess ( Id As Long, NumberOfPages As Integer, _
             AlreadyProcessed As Integer) As Integer
   On Error GoTo Failure

   If (AlreadyProcessed) Then
      KfxDocPreProcess = NoError
      Exit Function
   End If

   KfxDocPreProcess = NoError
   Exit Function

Failure:
   KfxDocPreProcess = FatalError
   Exit Function
End Function


REM ========================================================================
REM Function handling document post index processing.
REM This function can return NoError or FatalError.
REM ------------------------------------------------------------------------

Function KfxDocPostProcess ( Id As Long, DataAccepted As Integer) As Integer
   On Error GoTo Failure

   Dim Operation As String                ' example code
   If (DataAccepted = 1) Then             ' example code
      Operation = "Requested Save Index Data" ' example code
   Else                             ' example code
      Operation = "Cancelled Save Index Data" ' example code
   End If                              ' example code

   KfxDocPostProcess = NoError
   Exit Function

Failure:
   KfxDocPostProcess = FatalError
   Exit Function
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLPolicy_Number As String

                     ' Index field value.

Global KfxPolicy_Number As String

                     '===============================================
                                                        '===== SQL_CHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Policy_Number default value: ""
                     '-----------------------------------------------
Function PrePolicy_Number() As Integer
   On Error GoTo Failure
   PrePolicy_Number = NoError
   Exit Function
Failure:
   PrePolicy_Number = FatalError
   Exit Function
End Function
                     '----- Policy_Number validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostPolicy_Number( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
        If ( Len(EnteredValue) > MaxLength ) Then 
           msgbox "The Policy Number entered is too long." ,, "Please re-enter Claim Number."
           GoTo Failure
        End If

   Rem // Pad the Entered Value with zeroes to 8 digits
 
   If Len(EnteredValue) = 7 Then
      EnteredValue = "0" + EnteredValue
   Else
      If Len(EnteredValue) = 6 Then
         EnteredValue = "00" + EnteredValue
      Else 
         If Len(EnteredValue) = 5 Then
            EnteredValue = "000" + EnteredValue
         Else 
            If Len(EnteredValue) = 4 Then
               EnteredValue = "0000" + EnteredValue
            Else
               If Len(EnteredValue) = 3 Then
                  EnteredValue = "00000" + EnteredValue
               End If
            End If
         End If
      End If
   End If

 Rem // Based on Policy Number, retrieve the Insured and Tax_Id
  
   Dim SQL as Variant
   Dim Result as integer
   Dim PolicyArray(1 to 2, 1 to 50) as Variant
   
   SQL = "SELECT KS267, KS268 FROM HSI.KEYSETDATA132 WHERE KS181 = '" & EnteredValue & "'"
      
   Result = SQLExecQuery(Connection, SQL)
  
   If Result <= 0 then
     SQLError destination:=errors
     msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
     goto failure
   End if

   Result = SQLRetrieve(Connection, PolicyArray())   
     
   If Result = 0 then
      SQLError destination:=errors
      msgbox "The Policy Number entered is not on file." ,, "Policy Not Found" 
      goto failure
   End if 
   
   If Result = 0 then
     KfxInsured_Name   = " "
     KfxTax_Id         = " "
   else
     KfxInsured_Name   = PolicyArray(1,1)
     KfxTax_Id         = PolicyArray(2,1)
   end if
   
   If KfxInsured_Name = "" then
      msgbox "Insured Name is blank.  Please Reject this document.",,"Invalid Data"
      goto failure
   End If
   
 Rem // Pop up a window containing Insured Name and Tax ID for the Policy Number entered
   
   If KfxOperation = "Verify" Then
        dim msgtxt as string
        msgtxt = "Insured: "& KfxInsured_Name &""
        msgtxt = msgtxt + Chr(10) + Chr(10)
        msgtxt = msgtxt + "Tax ID: "
        msgtxt = msgtxt + ""& KfxTax_Id &""      
 rem       msgbox msgtxt,, "Insured Info"
   End If 
   
   KfxPolicy_Number  = EnteredValue
   PostPolicy_Number = NoError
   Exit Function
Failure:
   PostPolicy_Number = ValidationError
   Exit Function
End Function
                     '----- Policy_Number format
                     '-----------------------------------------------
Function FmtPolicy_Number() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtPolicy_Number = KfxPolicy_Number
   Exit Function
Failure:
   FmtPolicy_Number = KfxPolicy_Number
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLInsured_Name As String

                     ' Index field value.


                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Insured_Name default value: ""
                     '-----------------------------------------------
Function PreInsured_Name() As Integer
   On Error GoTo Failure
   if kfxoperation = "Index" then
       PreInsured_Name = SAVEANDSKIPFIELD
   end if
   'PreInsured_Name = NoError
   Exit Function
Failure:
   PreInsured_Name = FatalError
   Exit Function
End Function
                     '----- Insured_Name validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostInsured_Name( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxInsured_Name = EnteredValue
   PostInsured_Name = NoError
   Exit Function
Failure:
   PostInsured_Name = ValidationError
   Exit Function
End Function
                     '----- Insured_Name format
                     '-----------------------------------------------
Function FmtInsured_Name() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtInsured_Name = KfxInsured_Name
   Exit Function
Failure:
   FmtInsured_Name = KfxInsured_Name
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLTax_Id As String

                     ' Index field value.


                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Tax_Id default value: ""
                     '-----------------------------------------------
Function PreTax_Id() As Integer
   On Error GoTo Failure
   
   PreTax_Id = SAVEANDSKIPFIELD
   'PreTax_Id = NoError
   Exit Function
Failure:
   PreTax_Id = FatalError
   Exit Function
End Function
                     '----- Tax_Id validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostTax_Id( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxTax_Id = EnteredValue
   PostTax_Id = NoError
   Exit Function
Failure:
   PostTax_Id = ValidationError
   Exit Function
End Function
                     '----- Tax_Id format
                     '-----------------------------------------------
Function FmtTax_Id() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtTax_Id = KfxTax_Id
   Exit Function
Failure:
   FmtTax_Id = KfxTax_Id
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDocument_Type As String

                     ' Index field value.

Global KfxDocument_Type As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Document_Type default value: ""
                     '-----------------------------------------------
Function PreDocument_Type() As Integer
   On Error GoTo Failure
   PreDocument_Type = NoError
   Exit Function
Failure:
   PreDocument_Type = FatalError
   Exit Function
End Function
                     '----- Document_Type validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDocument_Type( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   dim size       as integer
   dim count      as integer
   dim x          as integer
   Dim Res        as integer
   Dim SQL        as Variant
   Dim Result     as integer
   Dim DocTypeArray(1 to 1, 1 to 500) as Variant
   Dim SearchString as String
      
   Rem // If user did not enter a Document Type, bring up a list of all document types. 
   
     If EnteredValue = "" Then
     
         ReDim DocTypeDlgArray(4) as String 
         DocTypeDlgArray(0) = "PCRB/CMCRB"
         DocTypeDlgArray(1) = "PCRB Construction Credit"
         DocTypeDlgArray(2) = "PCRB Correspondence"
         DocTypeDlgArray(3) = "PCRB Disapproval"
         DocTypeDlgArray(4) = "C Report"
     
     

 '       SQL = "SELECT ITEMTYPENAME From HSI.DocType WHERE ITEMTYPEGROUPNUM = '146' ORDER BY ITEMTYPENAME"
 '       Result = SQLExecQuery(Connection, SQL)
 ' 
 '       If Result <= 0 then
 '         SQLError destination:=errors
 '         msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
 '         goto failure
 '       End if
'
 '       Result = SQLRetrieve(Connection, DocTypeArray())   
 '    
 '       size = Result 
 '       ReDim DocTypeDlgArray(size) as String    
 '       count = 1     
 '       x     = 1
 '       Do    
 '         If Mid(DocTypeArray(1,count), 1, 2) <> "ZZ" Then 
 '           DocTypeDlgArray(x - 1) = DocTypeArray(1,count)
 '           x =  x + 1
 '         End If
 '         count = count + 1
 '       Loop Until count > size
 '    
        Begin Dialog DOCTYPEDIALOG 225, 36, 257, 160, "Document Type Selection"
           ListBox  0, 17, 256, 116, DocTypeDlgArray() , .ListBox1
           OkButton  17, 142, 42, 14
           PushButton  74, 142, 42, 14, "Cancel", .Cancel
           Text  3, 6, 135, 9, "Document Type"
        End Dialog
          
        Dim DisplayDialog as DOCTYPEDIALOG
        Res = dialog(DisplayDialog) 
      
       If Res = -1 then
          KfxDocument_Type = trim(DocTypeDlgArray(DisplayDialog.ListBox1))
          Exit Function
        Else
          Goto Failure
        End If  
     End If   
   
      Rem //Before anything, check quick enter items.  If match, fill index.
   
   If UCase(EnteredValue) = "RAE" Then
       KfxDocument_Type = "Request for Alternate Employers"
       PostDocument_Type = NoError
       Exit Function
   ElseIf UCase(EnteredValue) = "RCI" Then
       KfxDocument_Type = "Request for Certificate of Insurance"
       PostDocument_Type = NoError
       Exit Function
   End If
   
       
   Rem // Check for an exact match for the Entered Value.  If exact match, fill the 
   Rem // index field and move on.
   
     SQL = "SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) = Upper('" & EnteredValue & "') and ITEMTYPEGROUPNUM = '146'"
     Result = SQLExecQuery(Connection, SQL)
  
     If Result <= 0 then
       SQLError destination:=errors
       msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
       goto failure
     End if

     Result = SQLRetrieve(Connection, DocTypeArray())   
     
     If Result = 1 then
       KfxDocument_Type = trim(DocTypeArray(1,1))
       PostDocument_Type = NoError
       Exit Function
     End if 
   
   Rem // Build List of Claims Documents based on the value entered by the user.  The SQL result set will 
   Rem // include records that contain the entered value (wildcard search) 
     
'   SearchString = "%" + EnteredValue + "%"
'  SearchString = UCase(SearchString)   
'   SQL = "SELECT ITEMTYPENAME From HSI.DocType WHERE Upper(ITEMTYPENAME) Like '" & SearchString & "' and ITEMTYPEGROUPNUM = '146' ORDER BY ITEMTYPENAME"
'   
'   Result = SQLExecQuery(Connection, SQL)
' 
'    If Result <= 0 then
'      SQLError destination:=errors
'      msgbox str(errors(1,3)) &"#" & str(errors(1,3)),, "SQLExecQuery Error"
'      goto failure
'    End if
'
'     Result = SQLRetrieve(Connection, DocTypeArray())   
'     
'     If Result = 0 then
'        SQLError destination:=errors
'        msgbox "No similar Document Types Found." ,, "No Document Types Found" 
'        goto failure
'     End if   
'   
'     If Result = 1 then
'       KfxDocument_Type = trim(DocTypeArray(1,1))
'       PostDocument_Type = NoError
'      Exit Function
'    End if 
'     
'     size = Result 
'     ReDim DocTypeDlgArray(size) as String
'      
'
'
'     count = 1     
'     x     = 1
'     Do    
'      If Mid(DocTypeArray(1,count), 1, 2) <> "ZZ" Then 
'        DocTypeDlgArray(x - 1) = DocTypeArray(1,count)
'        x =  x + 1
'      End If
'      count = count + 1
'     Loop Until count > size

     ReDim DocTypeDlgArray(4) as String 
         DocTypeDlgArray(0) = "PCRB/CMCRB"
         DocTypeDlgArray(1) = "PCRB Construction Credit"
         DocTypeDlgArray(2) = "PCRB Correspondence"
         DocTypeDlgArray(3) = "PCRB Disapproval"
         DocTypeDlgArray(4) = "C Report"
     
     Begin Dialog DOCTYPEDIALOG2 229, 39, 261, 158, "Document Type Selection"
        ListBox  2, 12, 256, 120, DocTypeDlgArray() , .ListBox1
        OkButton  16, 139, 42, 14
        PushButton  73, 139, 42, 14, "Cancel", .Cancel
        Text  5, 2, 135, 9, "Document Type"
     End Dialog
 
     Dim DisplayDialog2 as DOCTYPEDIALOG2
     Res = dialog(DisplayDialog2) 
     
     If Res = -1 then
       KfxDocument_Type = trim(DocTypeDlgArray(DisplayDialog2.ListBox1))
     Else
       Goto Failure
     End If  
 
   PostDocument_Type = NoError
   Exit Function
Failure:
   PostDocument_Type = ValidationError
   Exit Function
End Function
                     '----- Document_Type format
                     '-----------------------------------------------
Function FmtDocument_Type() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDocument_Type = KfxDocument_Type
   Exit Function
Failure:
   FmtDocument_Type = KfxDocument_Type
End Function

REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDocument_Date As String

                     ' Index field value.

Global KfxDocument_Date As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- Document_Date default value: ""
                     '-----------------------------------------------
Function PreDocument_Date() As Integer
   On Error GoTo Failure
   PreDocument_Date = NoError
   Exit Function
Failure:
   PreDocument_Date = FatalError
   Exit Function
End Function
                     '----- Document_Date validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDocument_Date( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure

'Date validation added 2/22/07
'  Invalid dates and future dates are not allowed
   
   dim todayDate as string
   todayDate = Date
    
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   dim tempmm as string
   dim tempdd as string
   dim tempyyyy as string
   
   If Len(EnteredValue) = 6 Then
      tempmm = Mid(EnteredValue,1,2)
      tempdd = Mid(EnteredValue,3,2)
      tempyyyy = Mid(EnteredValue,5,2)
      If tempyyyy > "25" Then
        tempyyyy = "19" + tempyyyy
      else
         tempyyyy = "20" + tempyyyy
      End If
   Else
      If Len(EnteredValue) = 8 Then 
         tempmm = Mid(EnteredValue,1,2)
         tempdd = Mid(EnteredValue,3,2)
         tempyyyy = Mid(EnteredValue,5,4)
      Else
         If Len(EnteredValue) = 10 Then
            tempmm = Mid(EnteredValue,1,2)
            tempdd = Mid(EnteredValue,4,2)
            tempyyyy = Mid(EnteredValue,7,4)
         Else   
            msgbox "Invalid Date Format" ,, "Invalid Data"
            Goto Failure
         End If   
      End If
   End If
   
   EnteredValue = tempmm + "/" + tempdd + "/" + tempyyyy
      
   If Not IsDate(EnteredValue) Then
      msgbox "Invalid Date Format" ,, "Invalid Date"
      Goto Failure
   End If
   
   If CVDate(EnteredValue) > CVDate(todayDate) and KfxDocument_Type <> "Large Policy Document" Then
      msgbox "The date entered is greater than current date." ,, "Invalid Date"
      Goto Failure
   End If
   
   KfxDocument_Date = EnteredValue
   PostDocument_Date = NoError
   Exit Function
Failure:
   PostDocument_Date = ValidationError
   Exit Function
End Function
                     '----- Document_Date format
                     '-----------------------------------------------
Function FmtDocument_Date() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDocument_Date = KfxDocument_Date
   Exit Function
Failure:
   FmtDocument_Date = KfxDocument_Date
End Function




REM ========================================================================
REM
REM     Field Macro Name: 
REM
REM
REM ------------------------------------------------------------------------

                     ' Uncomment the global definition below if the
                     ' script is to have read-only access to the
                     ' index field's Confidence Level (CL).

'Global KfxCLDTN As String

                     ' Index field value.

Global KfxDTN As String

                     '===============================================
                     '===== SQL_VARCHAR Procedures
                     '-----------------------------------------------

' Return codes are defined by the document class customization script.

                     '----- DTN default value: ""
                     '-----------------------------------------------
Function PreDTN() As Integer
   On Error GoTo Failure
   PreDTN = NoError
   Exit Function
Failure:
   PreDTN = FatalError
   Exit Function
End Function
                     '----- DTN validation: checks
                     '----- to see if max length exceeded
                     '-----------------------------------------------

Function PostDTN( EnteredValue As String, MaxLength As Integer ) As Integer
   On Error GoTo Failure
   
   EnteredValue = Trim(EnteredValue)
   If ( Len(EnteredValue) > MaxLength ) Then GoTo Failure
   
   KfxDTN = EnteredValue
   PostDTN = NoError
   Exit Function
Failure:
   PostDTN = ValidationError
   Exit Function
End Function
                     '----- DTN format
                     '-----------------------------------------------
Function FmtDTN() As String
   'The On Error is here to trap unexpected exceptions, however this function
   'does not return a status.
   On Error GoTo Failure
   FmtDTN = KfxDTN
   Exit Function
Failure:
   FmtDTN = KfxDTN
End Function

Sub Main
dim Result as Integer
Result = KfxLoadValidation(1,0)
Result = PostDocument_Type("rci",50)
'Result = PostPolicy_Number("04453871",12)
'Result = PostDocument_Date("1/31/2004", 10)
'Result = PreDocument_Date()
End Sub
